# bot-facebook

สอนใช้BOT
____________________________
1.หาappstate.json แล้วเอามาใส่
วิธีหา
>https://youtu.be/q6F70f0Pgjc
____________________________
2.รัน node bot.js
____________________________
3.command bot "!help"
